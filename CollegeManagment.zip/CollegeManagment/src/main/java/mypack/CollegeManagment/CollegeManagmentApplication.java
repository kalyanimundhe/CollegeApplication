package mypack.CollegeManagment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollegeManagmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(CollegeManagmentApplication.class, args);
	}

}
